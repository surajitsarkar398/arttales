<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Service\ApiService;
use App\Http\Controllers\Repository\ApiRepository;
use App\Models\Preference;
use App\Http\Controllers\Msg;
use App\Http\Utility\DataService;
use Illuminate\Support\Facades\Auth; 
use App\Models\User;
use Validator;

class apiController extends Controller
{

    // Register User Api

    public function register(Request $request){
        $data = $request->all(); 
        $error_msg = new Msg();
        $ApiService = new ApiService();

        if($request->method() == 'POST'){

            $rules = array(
                        'name'        => 'required|max:255',
                        'country_code'=> 'required|max:3',
                        'mobile'      => 'required|max:255',
                        'dob'         => 'required|date',
                        'email'       => 'required|email|max:255|unique:users',
                        'password'    => 'required',
                        'repasswprd'  => 'required',
                        'role'        => 'required');

            $validation = Validator::make($data,$rules);
        
            if($validation->fails()){
            
                $validation_error = $validation->errors()->all();
                $msg =  $error_msg->responseMsg(403);
                $response = ['code' => 403,'status' => false, 'msg'=>$validation_error[0]];
                
            }else{
                $Check = $ApiService->register($data);
                $msg =  $error_msg->responseMsg($Check->error_code);
                if($Check->error_code == 636){

                    $response = ['code' => 200,'status' => true, 'msg'=>  $msg];

                }else{
                    $response = ['code' => $Check->error_code,'status' => false, 'msg'=>  $msg];
                }
            } 

            return $response;
        }
    }
    

    //Login User APi

    public function login(Request $request){

        $data = $request->all();   
        $error_msg = new Msg();
        $ApiService = new ApiService();
        if($request->method() == 'POST'){
            
            $rules = array('email' => 'required','password' => 'required');
        
            $validation = Validator::make($data,$rules);

            if($validation->fails()){   
                $validation_error = $validation->errors()->all();
                $msg =  $error_msg->responseMsg(403);
                $response = ['status' => 1,'message'=> $validation_error[0]];
            
            }else{
               
                $Check = $ApiService->login($data);
                $msg =  $error_msg->responseMsg($Check->error_code);
                
                if($Check->error_code == 200){

                    $response = ['status' => 0, 'message'=>  $msg, 'data' => $Check->data];
                    

                }else{
                    $response = ['code' => $Check->error_code,'message'=>  $msg ];
                }

            }

            return $response;
        }
        
        
    }


    //fatch user details
    public function fetchUser(Request $request){

        $data = $request->all();   
        $error_msg = new Msg();
        $ApiService = new ApiService();
        //print_r($data);die;
        if($request->method() == 'POST'){
            
            $rules = array('register_id' => 'required');
        
            $validation = Validator::make($data,$rules);

            if($validation->fails()){   
                $validation_error = $validation->errors()->all();
                $msg =  $error_msg->responseMsg(403);
                $response = ['code' => 403,'msg'=> $validation_error[0]];
            
            }else{
               
                $Check = $ApiService->fetchUser($data);
                $msg =  $error_msg->responseMsg($Check->error_code);
                
                if($Check->error_code == 643){

                    $response = ['code' => 200, 'msg'=>  $msg, 'data' => $Check->data];
                    

                }else{
                    $response = ['code' => $Check->error_code,'msg'=>  $msg ];
                }

            }

            return $response;
        }
    }
    

    public function preferenceListing(Request $request){

        $ApiRepository = new ApiRepository;
        $preferenceList = $ApiRepository->getAllPefrence();
        $error_msg = new Msg();
        if(isset($preferenceList)){

            $msg =  $error_msg->responseMsg(643);
            $response = ['code' => 200, 'msg'=>  $msg, 'data' => $preferenceList];
                    
        }
        else{
            $msg =  $error_msg->responseMsg(425);
            $response = ['code' => 425,'msg'=>  $msg ];
        }
        return $response;
    }   

    public function profile(Request $request){
       
    
        if($request->method() == 'POST'){

            $data = $request->all();
            
            $Is_method = 0;
            $ApiService = new ApiService();
            $Check = $ApiService->profile($Is_method,$data);
            
            $error_msg = new Msg();
            $msg =  $error_msg->responseMsg($Check->error_code);
        
            if($Check->error_code == 217){
                $response = [
                    'code'  =>  200,
                    'msg'   =>  $msg,
                    'data'  =>  $Check->data  
                ];
            }else{
                $response = [
                    'code' => $Check->error_code,
                    'msg'=>  $msg
                ];
            }

        }      
        return $response;
    }

   
}
