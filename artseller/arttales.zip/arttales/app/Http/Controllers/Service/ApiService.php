<?php

namespace App\Http\Controllers\Service;

use App\Http\Controllers\Repository\ApiRepository;
use App\Models\User;
use App\Models\Preference;
use App\Models\Contact;
use App\Http\Utility\DataService;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth; 

Class ApiService{

	public function login($arg){
		
		$data = 	new DataService();
		$ApiRepository = new ApiRepository();
			 /*  $pass = "123456";
			    $hp= hash::make($pass);
			    print_r($hp);
			    die;*/
		
		if(Auth::attempt( ['email' => $arg['email'], 'password' => $arg['password'] ]) ){
			$user= Auth::user();
			$arg['register_id'] 		= $user->register_id;
			$getUser  					= $ApiRepository->login($arg);	
			if($getUser){
				$data->error_code = 200;
				$data->data = $getUser;
			}
		}else{
			$data->error_code = 430;
	 	}	
 		return $data;
	}


	public function register($arg){

		$data = 	new DataService();
		$ApiRepository = new ApiRepository();
		$create_user = $ApiRepository->register($arg);
		if($create_user){
			$data->error_code = 636;
		}else{
			$data->error_code = 637;
		}
		return $data;
	}


	public function forgotPassword($arg){

		$data = 	new DataService();
		$ApiRepository = new ApiRepository();
			
		if(isset($arg['email'])){
			$getuser = $ApiRepository->login($arg);	
			if(isset($getuser['id']) && $getuser['id'] >= 0 ){
				$update_password = $ApiRepository->forgot_password($arg,$getuser);	

				if($update_password){

					$data->error_code = 601;
				
				}else{

					$data->error_code = 470;
				}

			}else{

				$data->error_code = $getuser['code'];

			}

		}

		return $data;
	}


	public function resetPassword($arg){

		$data = 	new DataService();
		$ApiRepository = new ApiRepository();

		if(isset($arg['email']) && isset($arg['code']) && isset($arg['password'])){

			$getuser = $ApiRepository->Checkuser($arg);
	
			if(isset($getuser->id) && $getuser->id >= 0 ){

				$reset_password = $ApiRepository->resetPassword($arg,$getuser);	
				$data->error_code = $reset_password;
			
			}else{

				$data->error_code = 638;
			
			}

		}

		return $data;
	}



	public function profile($method,$arg){

		$data = new DataService();
		$ApiRepository = new ApiRepository();

			
		if($method == 0){ 
	
			$arg['register_id'] = Auth::user()->register_id;
			$update = $ApiRepository->updateprofile($arg);
		

			if($update['code'] == 200){

				unset($update['code']);
				$data->error_code = 217;
				$data->data = $update; 

			}else if($update['code'] == 410){
					
				$data->error_code = $update['code'];
			
			}else{

				$data->error_code = 632;
			}  
		
		}	
	
		return $data;
	}


	public function change_password($arg){

		$data = new DataService();
		$ApiRepository = new ApiRepository();

		if(isset($arg['old_password']) &&  isset($arg['new_password'])){
			$arg['id'] = Auth::user()->id;
			$update = $ApiRepository->change_password($arg);
			//print_r($update);die;
			if($update['code'] == 204){

				$data->error_code = 204;
				
			}else if($update['code'] == 640){
					
				$data->error_code = 640;
			
			}  
		
		}else{

			$data->error_code = 403;

		}

		return $data;

	}

	public function fetchUser($arg){
		//print_r($arg['register_id']);die;
		$data = 	new DataService();
		$ApiRepository = new ApiRepository();
		
		if($arg['register_id'] ){ 
			
			$user = User::getUser($email=null,$arg['register_id']);
			$arg['register_id'] 		= $user->register_id;
			$getUser  					= $ApiRepository->fetchUser($arg);
			//print_r($getUser);die;	
			if($getUser){
				$data->error_code = 643;
				$data->data = $getUser;
			}
	 	}else{
	 		$data->error_code = 642;
	 	}	
 		return $data;
	}


	public function preferencelisting($arg){

		$data 			= new DataService();
		$ApiRepository 	= new ApiRepository();
		$show_preferencelisting 	= $ApiRepository->preferencelisting($arg);
		if($show_preferencelisting){
			$data->error_code = 643;
		}else{
			$data->error_code = 425;
		}
		return $data;
	}

	public function contact($arg){

		$data = 	new DataService();
		$ApiRepository = new ApiRepository();
		$create_contact = $ApiRepository->register($arg);
		if($create_contact){
			$data->error_code = 636;
		}else{
			$data->error_code = 637;
		}
		return $data;
	}






}



