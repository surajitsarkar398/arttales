<?php

namespace App\Http\Controllers\Repository;

use App\Models\User;
use App\Models\token;
use App\Models\Preference;
use App\Models\Contact;
use App\Models\Photo;
use App\Http\Utility\CustomVerfication;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Utility\SendEmails;
use Illuminate\Support\Facades\URL;
use Auth;


Class ApiRepository extends User{
  private $access_token;
	private $token_id;
  public function __construct()
	{
	    // access  token
	   $this->token_id = mt_rand();	
	   $this->access_token = sha1 (md5("ARTTALES".$this->token_id."!@#$%^&*!!"));
	}	

	public function login($data){
      
    if(isset($data['register_id'])){
		  $getUsers = User::getUser($email=null,$data['register_id']);
      $acesstoken = $this->access_token;

        $token = new token;
        $token->register_id = $data['register_id'];
        $token->token =$acesstoken;
        $token->save();
    }
    
    

        if(isset($getUsers)){   
          $userdata['register_id']  = 	$getUsers->register_id;
          $userdata['name']  	    	= 	$getUsers->name ? 	$getUsers->name : '';
          $userdata['country_code'] = 	$getUsers->country_code ? 	$getUsers->country_code : '';
          $userdata['mobile']  		  = 	$getUsers->mobile ? 	$getUsers->mobile : '';
          $userdata['dob'] 	        =	  $getUsers->dob ? $getUsers->dob : '';
          $userdata['email'] 			  = 	$getUsers->email 	? 	$getUsers->email : '';
          $userdata['image'] 			  = 	$getUsers->image 	? 	$getUsers->image : '';
          $userdata['bio'] 		      = 	$getUsers->bio 	?	$getUsers->bio: '';
          $userdata['website'] 		  =	  $getUsers->website ? $getUsers->website : '';
          $userdata['major_achive'] =	  $getUsers->major_achive ? $getUsers->major_achive : '';
          $userdata['genres'] 	    =	  $getUsers->genres ? $getUsers->genres : '';
          $userdata['work_at'] 	    =	  $getUsers->work_at ? $getUsers->work_at : '';
          $userdata['performance'] 	=	  $getUsers->performance ? $getUsers->performance : '';
          $userdata['visiting_card']= 	$getUsers->visiting_card 	? 	$getUsers->visiting_card : '';
          $userdata['access_token'] =   $acesstoken;
          $userdata['role'] 			  = 	$getUsers->role 	? 	$getUsers->role : '';
          
        }else{

          $userdata['code'] = 461;
        }  
      
        return $userdata;
	}


    public function register($data){
      $CustomVerfication = new CustomVerfication;
      $path = "register";
        $image = $data['image'] ?? null;
        if($image !=null){
          $image= $CustomVerfication->imageUpload($image,$path);
        }else{
          $image = null;
        }

        $visting = $data['visiting_card'] ?? null;
        if($visting !=null){
          $visiting_card= $CustomVerfication->imageUpload($visting,$path);
        }else{
          $visiting_card = null;
        }
        
     
        $user = new User;
        
        $user->name                = $data['name'];
        $user->country_code        = $data['country_code'];
        $user->mobile              = $data['mobile'];
        $user->dob                 = $data['dob'];
        $user->email               = $data['email'];
        $user->password            = hash::make( $data['password']);
        $user->repasswprd          = hash::make( $data['repasswprd']);
        $user->image               = $image;
        $user->bio                 = $data['bio'];
        $user->website             = $data['website'];
        $user->major_achive        = $data['major_achive'];
        $user->genres              = $data['genres'];
        $user->work_at             = $data['work_at'];
        $user->performance         = $data['performance'];
        $user->visiting_card       = $visiting_card;
        $user->role                = $data['role'];
        
        $user->save();
      
      return $user;
      
  }

  public function forgot_password($data,$user){

    $data['forgot_type'] = 1;
    $SendEmail = new SendEmails();
    $getuser = User::find($user['id']);
    $PhoneVerification = new CustomVerfication();
    $rescod = "";

    if($data['forgot_type'] == 1){

      if(@$data['phone'] != ''){
        $pass = 1234;  //mt_rand (1000, 9999) ;
        $getuser->forgot_password_code = $pass;
      }else{

        $pass = mt_rand (1000, 9999) ;
        $getuser->forgot_password_code = $pass;
      }

      $getuser->forgot_password_date = date ( 'Y-m-d H:i:s' );
      unset($getuser->password);
      $getuser->save();

      if(@$data['email'] != ''){
        $email = $getuser->email;
        $name =  $getuser->username;
        $newpassword =  $pass;
        $SendEmail->sendUserEmailforgot($email,$name,$newpassword,$data['forgot_type']);
        $rescod = 601;
      }

      $lastId = $getuser->id;
      $country_code = '';
      $code =  $pass ;
      $message = "Your SingleFord verification Code is ". $code;

      if(@$data ['phone'] != ''){
        $verify = $PhoneVerification->phoneVerification($message,$data['phone']);
        $rescod = 601;
      }
    }
    return $rescod;

  }

  public function resetPassword($data,$user){
    $getuser = User::findorfail($user->id);
    $rescod = "";
    if($getuser->forgot_password_code == $data['code'] ){
      $getuser->forgot_password_code = "";
      $getuser->password = hash::make($data['password']);      
      $getuser->save();      
      $rescod = 639;
    }else{

      $rescod = 422;
    }

    return $rescod;
  } 


  public function Checkuser($data){

    if(isset($data['email']) && isset($data['code'])){
      $getUsers = User::where('email',$data['email'])
              ->where('forgot_password_code',$data['code'])->first();  
      
    }else if(isset($data['id'])){

     $getUsers = User::findorfail($data['id']);  

    }
    
    return $getUsers;
  }

  public function updateprofile($data){
    
    $getUsers   = User::find($data['register_id']);
    $query  = 0;
    if(isset($data['email'])){
      $query = User::where('email',@$data['email'])->where('register_id','!=',@$data['register_id'])->count();
    }


    if($query == 0){
      $getUsers->register_id            =  @$data['register_id'] ? @$data['register_id'] : $getUsers->register_id;
      $getUsers->name                   =  @$data['name'] ? @$data['name'] : $getUsers->name;
      $getUsers->country_code           =  @$data['country_code'] ? @$data['country_code'] : $getUsers->country_code;
      $getUsers->mobile                 =  @$data['mobile'] ? @$data['mobile'] : $getUsers->mobile;
      $getUsers->dob                    =  @$data['dob'] ? @$data['dob'] : $getUsers->dob;
      $getUsers->email                  =  @$data['email'] ? @$data['email'] : $getUsers->email;
      $getUsers->image                  =  @$data['image'] ? @$data['image'] : $getUsers->image;
      $getUsers->bio                    =  @$data['bio']  ? @$data['bio'] : $getUsers->bio;
      $getUsers->website                =  @$data['website'] ? @$data['website'] : $getUsers->website;
      $getUsers->major_achive           =  @$data['major_achive'] ? @$data['major_achive']: $getUsers->major_achive;
      $getUsers->genres                 =  @$data['genres'] ? @$data['genres']:$getUsers->genres;
      $getUsers->work_at                =  @$data['work_at'] ? @$data['work_at']:$getUsers->work_at;
      $getUsers->performance            =  @$data['performance'] ? @$data['performance']:$getUsers->performance;
      $getUsers->visiting_card          =  @$data['visiting_card'] ? @$data['visiting_card']:$getUsers->visiting_card;
      
      $getUsers->save();


      $userdata['register_id']           =   $getUsers->register_id;
      $userdata['name']                  =   $getUsers->name ?   $getUsers->name : '';
      $userdata['country_code']          =   $getUsers->country_code  ?   $getUsers->country_code : '';
      $userdata['mobile']                =   $getUsers->mobile   ?   $getUsers->mobile : '';
      $userdata['dob']                   =   $getUsers->dob  ? $getUsers->dob: '';
      $userdata['email']                 =   $getUsers->email  ?   $getUsers->email : '';
      $userdata['image']                 =   $getUsers->image ? $getUsers->image : '';
      $userdata['bio']                   =   $getUsers->bio ? $getUsers->bio : '';
      $userdata['description']           =   $getUsers->description ? $getUsers->description : '';
      $userdata['website']               =   $getUsers->website ? $getUsers->website : '';
      $userdata['major_achive']          =   $getUsers->major_achive ? $getUsers->major_achive : '';
      $userdata['genres']                =   $getUsers->genres ? $getUsers->genres : '';
      $userdata['work_at']               =   $getUsers->work_at  ? $getUsers->work_at : '';
      $userdata['performance']           =   $getUsers->performance ? $getUsers->performance : '';
      $userdata['visiting_card']         =   $getUsers->visiting_card ? $getUsers->visiting_card : '';
      $userdata['role']                  =   $getUsers->role   ?   $getUsers->role : '';
      $userdata['code'] = 200;
    
    }else{

      $userdata['code'] = 410;
    }

    return $userdata;

  }

  public function change_password($data){

    $getUsers   = User::find($data['id']);
    $Checkuser = Auth::attempt(array('email' => $getUsers->email, 'password' => $data['old_password']));
    //$Checkuser = Auth::check($data['old_password'], $getUsers->password);
    if($Checkuser){

      $getUsers   = User::find($data['id']);
      $getUsers->password = bcrypt($data['new_password']);          
      $getUsers->save();
      $userdata['code'] = 204;
    
    }else{

      $userdata['code'] = 640;

    }

    return $userdata;
  }


  public function fetchUser($data){
      
    if(isset($data['register_id'])){
		  $getUsers = User::getUser($email=null,$data['register_id']);
      $acesstoken = $this->access_token;
    }
        if(isset($getUsers)){   
          $userdata['register_id']  = 	$getUsers->register_id;
          $userdata['name']  	    	= 	$getUsers->name ? 	$getUsers->name : '';
          $userdata['country_code'] = 	$getUsers->country_code ? 	$getUsers->country_code : '';
          $userdata['mobile']  		  = 	$getUsers->mobile ? 	$getUsers->mobile : '';
          $userdata['dob'] 	        =	  $getUsers->dob ? $getUsers->dob : '';
          $userdata['email'] 			  = 	$getUsers->email 	? 	$getUsers->email : '';
          $userdata['image'] 			  = 	$getUsers->image 	? 	$getUsers->image : '';
          $userdata['bio'] 		      = 	$getUsers->bio 	?	$getUsers->bio: '';
          $userdata['website'] 		  =	  $getUsers->website ? $getUsers->website : '';
          $userdata['major_achive'] =	  $getUsers->major_achive ? $getUsers->major_achive : '';
          $userdata['genres'] 	    =	  $getUsers->genres ? $getUsers->genres : '';
          $userdata['work_at'] 	    =	  $getUsers->work_at ? $getUsers->work_at : '';
          $userdata['performance'] 	=	  $getUsers->performance ? $getUsers->performance : '';
          $userdata['visiting_card']= 	$getUsers->visiting_card 	? 	$getUsers->visiting_card : '';
          $userdata['access_token'] =   $acesstoken;
          $userdata['role'] 			  = 	$getUsers->role 	? 	$getUsers->role : '';
          
        }else{

          $userdata['code'] = 461;
        }  
      
        return $userdata;
	}
  
  public function getAllPefrence()

      {
          $preferenceList = Preference::get();
          return $preferenceList;
      }

    public function contact($data){

      
        $user = new Contact;
        
        $user->name                = $data['name'];
        $user->email               = $data['email'];
         $user->mesage              = $data['message'];
     
        
        $user->save();
      
      return $user;
      
  }


  
} 
