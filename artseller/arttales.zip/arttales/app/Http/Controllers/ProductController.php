<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\User;
use App\Models\Store;
use Validator;
use App\Http\Utility\CustomVerfication;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;



class ProductController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
    $productlist = Product::orderBy('product_id', 'DESC')
      ->Paginate(10);

    return view('product.view', compact('productlist'));
  }

  public function sellproduct()
  {
    $productlist = DB::table('products')
      ->join('users', 'products.register_id', '=', 'users.register_id')
      ->join('stores', 'products.store_id', '=', 'stores.store_id')
      ->select('products.*', 'users.name', 'stores.store_name')
      ->where('sell_product', '1')
      ->get();


    return view('product.sellproduct', compact('productlist'));
  }


  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    //
    return view('product.addproduct');
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {

    $CustomVerfication = new CustomVerfication;
    $path = "post";
    $image = $data['post_image'] ?? null;
    if ($image != null) {
      $image = $CustomVerfication->imageUpload($image, $path);
    } else {
      $image = null;
    }
    $tags[] = $data['tags'] ?? null;

    $user = new Post;
    $user->post_image        = $image;
    $user->descriptions      = $data['descriptions'];
    $user->tags              = implode(',', $tags);
    $user->type              = $data['type'];
    $user->register_id       = $data['register_id'];
    $user->product_id      = $data['product_id'];
    $user->save();
    if($type == 1){
      if(isset($data['product_image']))
      {
        foreach($data['product_image'] as $file)
        {
          $image = $file ?? null;
          if($image !=null){                                                       
            $imagedata[]= $CustomVerfication->imageUpload($image,$path);
          }else{
            $imagedata = null;
          }  
        }
      }
      $user1 = new Product;
      $user1->product_name         = $data['product_name'];
      $user1->price                = $data['price'];
      $user1->discount             = $data['discount'];
      $user1->offer_price          = $data['offer_price'];
      $user1->product_image        = implode(',',$imagedata);
      $user1->product_description  = $data['product_description'];
      $user1->limited_stock        = $data['limited_stock'];
      $user1->sell_product         = $data['sell_product'];
      $user1->post_id              = $user->post_id;
      $user1->save();

      $post = Post::where('post_id',$user->post_id)->first();
      $post->product_id = $user1->product_id;
      $post->save();
    }
    return redirect('/product')->with('success','Product Added successfully.');
  }
    


    // $data = $request->all();

    // $rules = array(
    //   'product_name' => 'required',
    //   'price'  => 'required',
    //   'discount' => 'required',
    //   'offer_price' => 'required',
    //   'product_description' => 'required',
    //   'product_image' => 'required',
    //   'limited_stock' => 'required',
    // );

    //print_r($data);die;
    // $validation = Validator::make($data, $rules);
    // if ($validation->fails()) {
    //   // print_r($validation->errors()->all());
    //   return redirect()->back()->withInput()->withErrors($validation);
    // } else {
      // $path = "product";
      // $image= $CustomVerfication->imageUpload($data['product_image'],$path);


      // print_r($data['image']);die;

      // $files =  $request->file('product_image');
      // $images = array();
      // $path = "product";
      // foreach ($files as $file) {

      //   $image = $file ?? null;
      //   if ($image != null) {
      //     $images[] = $CustomVerfication->imageUpload($image, $path);
      //   } else {
      //     $images = null;
      //   }
      // }

      // $images=array();
      //  if($files=$request->file('product_image'))
      //  {
      //      foreach($files as $file){
      //        $path = "product";
      //        $image= $CustomVerfication->imageUpload($data['product_image'],$path);
      //          $images[]=$image;
      //      }
      //  }

      // $data['product_image'] = implode(',', $images);
      // Product::create($data);
      // return redirect('/product/addproduct/')->with('success', 'Product Added successfully.');
      /*return redirect()->route('/user/addartist/')
                            ->with('success','User Add successfully.');*/
      


  /**
   * Display the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function show()
  {
    //
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit(Request $request)
  {
    $productlist = Product::where('product_id', $request->id)->first();
    return view('product.editproduct', compact('productlist'));
  }

  /**
   * Update the specified resource in storage.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function saveEdit(Request $request)
  {
    $productlist = Product::where('product_id', $request->products_id)->first();

    $productlist->product_name = $request->product_name ?? $productlist->product_name;

    $productlist->price = $request->price ?? $productlist->price;

    $productlist->offer_price = $request->offer_price ?? $productlist->offer_price;

    $productlist->discount  = $request->discount  ?? $productlist->discount;

    $productlist->product_description  = $request->product_description  ?? $productlist->product_description;

    $productlist->limited_stock  = $request->limited_stock  ?? $productlist->limited_stock;

    $CustomVerfication = new CustomVerfication;

    $files =  $request->file('product_image');
    $images = array();
    $path = "product";

    foreach ($files as $file) {

      $image = $file;
      if ($image) {
        $images[] = $CustomVerfication->imageUpload($image, $path);
      } else {
        $images = null;
      }
    }

    $imagep = $request->images;


    if (!empty($images) && !empty($imagep)) {
      $result = array_merge($images, $imagep);
      $productlist = implode(',', $result);
    } elseif (!empty($images) && empty($imagep)) {
      $result = $images;
      $productlist = implode(',', $result);
    } elseif (empty($images) && !empty($imagep)) {
      $result = $imagep;
      $productlist = implode(',', $result);
    } else {
      $result = "";
    }


    $productlist->save();

    return redirect('/product')->with('success', 'Product Has Been Updated');
  }
  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    Product::where('product_id', '=', $id)->delete();
    return redirect('/product/viewproduct/')->with('success', 'Product Has Deleted');
  }
}
